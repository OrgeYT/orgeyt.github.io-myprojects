**Run the vbs file to run the converter**



Get FNFBOT from here: [FNFBOT](https://github.com/Kade-github/FNFBot/releases/tag/2.3)

