@echo off
start /b "" powershell -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0main.ps1"
exit