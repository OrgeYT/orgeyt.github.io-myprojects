Set WshShell = CreateObject("WScript.Shell")
Set FSO = CreateObject("Scripting.FileSystemObject")

scriptDir = FSO.GetParentFolderName(WScript.ScriptFullName)
batFile = FSO.BuildPath(scriptDir, "fnfbotdata\start.bat")

WshShell.Run Chr(34) & batFile & Chr(34), 0, False