<#
    Psych Engine -> FNFBOT Chart Converter (GUI)
    ----------------------------------------------
    A dark-themed Windows Forms app that mirrors the "Psych to FNFBOT
    Converter" web page (index.html / main.js) exactly:

      1. Load a Psych Engine chart JSON (v0.7+ {song:{notes:[...]}}
         format, or a raw {notes:[...]} chart).
      2. Strip the "events" array (FNFBOT chokes on it).
      3. Rebuild every section's notes as [time, direction, length],
         dropping any note flagged as a "Hurt Note".
      4. Apply the chosen mustHitSection handling mode:
           - Default   : keep each section's own mustHitSection value
                         (missing -> true)
           - All False : force every section to false, and mirror
                         (swap) note columns 0-3 <-> 4-7
           - All True  : force every section to true, columns
                         untouched
      5. Wrap the result as { "song": ... } and save it to
         .\converted\<original file name>

    Run it by right-clicking this file and choosing
    "Run with PowerShell", or from a terminal:
        powershell -ExecutionPolicy Bypass -File .\PsychToFNFBOT.ps1
#>

# --- Make sure we're on an STA thread (needed for dialogs / drag&drop) ---
if ([System.Threading.Thread]::CurrentThread.GetApartmentState() -ne 'STA') {
    Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
    exit
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)

# =====================================================================
#  Colors (matches the site's slate/cyan dark theme)
# =====================================================================
$ColorBg        = [System.Drawing.Color]::FromArgb(15, 23, 42)
$ColorPanel     = [System.Drawing.Color]::FromArgb(30, 41, 59)
$ColorPanelAlt  = [System.Drawing.Color]::FromArgb(15, 23, 42)
$ColorBorder    = [System.Drawing.Color]::FromArgb(51, 65, 85)
$ColorBorderHov = [System.Drawing.Color]::FromArgb(59, 130, 246)
$ColorTextMain  = [System.Drawing.Color]::FromArgb(248, 250, 252)
$ColorTextSub   = [System.Drawing.Color]::FromArgb(148, 163, 184)
$ColorTextDim   = [System.Drawing.Color]::FromArgb(100, 116, 139)
$ColorAccent    = [System.Drawing.Color]::FromArgb(34, 211, 238)
$ColorBtn       = [System.Drawing.Color]::FromArgb(8, 145, 178)
$ColorBtnHover  = [System.Drawing.Color]::FromArgb(6, 182, 212)
$ColorBtnOff    = [System.Drawing.Color]::FromArgb(51, 65, 85)
$ColorBtnOffTxt = [System.Drawing.Color]::FromArgb(148, 163, 184)
$ColorOk        = [System.Drawing.Color]::FromArgb(74, 222, 128)
$ColorOkBg      = [System.Drawing.Color]::FromArgb(20, 45, 30)
$ColorErr       = [System.Drawing.Color]::FromArgb(248, 113, 113)
$ColorErrBg     = [System.Drawing.Color]::FromArgb(50, 20, 20)

# =====================================================================
#  Helpers
# =====================================================================
function Test-HasProperty {
    param($Object, [string]$Name)
    if ($null -eq $Object) { return $false }
    return [bool]($Object.PSObject.Properties.Name -contains $Name)
}

function Set-PropertySafe {
    param($Object, [string]$Name, $Value)
    if (Test-HasProperty $Object $Name) {
        $Object.$Name = $Value
    } else {
        $Object | Add-Member -NotePropertyName $Name -NotePropertyValue $Value -Force
    }
}

function ConvertTo-NumberOrZero {
    param($Value)
    if ($Value -is [int] -or $Value -is [long]) { return $Value }
    if ($Value -is [double] -or $Value -is [decimal] -or $Value -is [single]) {
        if ($Value -eq [math]::Floor($Value)) { return [long]$Value }
        return $Value
    }
    try {
        $n = [double]$Value
        if ([double]::IsNaN($n)) { return 0 }
        if ($n -eq [math]::Floor($n)) { return [long]$n }
        return $n
    } catch {
        return 0
    }
}

# Parses raw JSON text and returns the "song" object - same Basic Psych
# v0.7+ check as main.js.
function Get-PsychData {
    param([string]$RawText)
    $json = $RawText | ConvertFrom-Json -ErrorAction Stop
    if ((Test-HasProperty $json 'song') -and ($null -ne $json.song) -and
        (Test-HasProperty $json.song 'notes') -and ($null -ne $json.song.notes)) {
        return $json.song
    } elseif ((Test-HasProperty $json 'notes') -and ($json.notes -is [array])) {
        return $json
    } else {
        throw "Doesn't look like a valid Psych Chart."
    }
}

# =====================================================================
#  Form
# =====================================================================
$form = New-Object System.Windows.Forms.Form
$form.Text = "Psych to FNFBOT Converter"
$form.ClientSize = New-Object System.Drawing.Size(460, 540)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.BackColor = $ColorBg
$form.Font = New-Object System.Drawing.Font('Segoe UI', 9)

# --- Title ---
$titleLabel = New-Object System.Windows.Forms.Label
$titleLabel.Text = "FNFBOT Chart Fixer"
$titleLabel.Font = New-Object System.Drawing.Font('Segoe UI', 17, [System.Drawing.FontStyle]::Bold)
$titleLabel.ForeColor = $ColorAccent
$titleLabel.TextAlign = 'MiddleCenter'
$titleLabel.Location = New-Object System.Drawing.Point(20, 18)
$titleLabel.Size = New-Object System.Drawing.Size(420, 34)
$form.Controls.Add($titleLabel)

# --- Subtitle ---
$subLabel = New-Object System.Windows.Forms.Label
$subLabel.Text = "Convert modern Psych charts for use with old-school bots."
$subLabel.Font = New-Object System.Drawing.Font('Segoe UI', 8.5)
$subLabel.ForeColor = $ColorTextSub
$subLabel.TextAlign = 'MiddleCenter'
$subLabel.Location = New-Object System.Drawing.Point(20, 52)
$subLabel.Size = New-Object System.Drawing.Size(420, 20)
$form.Controls.Add($subLabel)

# --- Drop zone (click or drag & drop a chart) ---
$script:dropHover = $false
$script:dropText = "Click or Drag JSON here"
$script:dropSubText = "Accepts Psych v0.7+ format"

$dropPanel = New-Object System.Windows.Forms.Panel
$dropPanel.Location = New-Object System.Drawing.Point(20, 82)
$dropPanel.Size = New-Object System.Drawing.Size(420, 110)
$dropPanel.BackColor = $ColorPanel
$dropPanel.Cursor = [System.Windows.Forms.Cursors]::Hand
$dropPanel.AllowDrop = $true

$dropPanel.Add_Paint({
    param($s, $e)
    $g = $e.Graphics
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias

    $borderColor = if ($script:dropHover) { $ColorBorderHov } else { $ColorBorder }
    $pen = New-Object System.Drawing.Pen($borderColor, 2)
    $pen.DashStyle = [System.Drawing.Drawing2D.DashStyle]::Dash
    $g.DrawRectangle($pen, 1, 1, $s.Width - 3, $s.Height - 3)
    $pen.Dispose()

    # simple document icon drawn with primitives (no font/emoji dependency)
    $iconW = 30; $iconH = 34
    $iconX = [int](($s.Width - $iconW) / 2)
    $iconY = 8
    $iconPen = New-Object System.Drawing.Pen($ColorTextDim, 2)
    $g.DrawRectangle($iconPen, $iconX, $iconY, $iconW, $iconH)
    $g.DrawLine($iconPen, $iconX + 5, $iconY + 10, $iconX + $iconW - 5, $iconY + 10)
    $g.DrawLine($iconPen, $iconX + 5, $iconY + 17, $iconX + $iconW - 5, $iconY + 17)
    $g.DrawLine($iconPen, $iconX + 5, $iconY + 24, $iconX + $iconW - 12, $iconY + 24)
    $iconPen.Dispose()

    $mainFont = New-Object System.Drawing.Font('Segoe UI', 10.5, [System.Drawing.FontStyle]::Bold)
    $subFont = New-Object System.Drawing.Font('Segoe UI', 8)
    $mainBrush = New-Object System.Drawing.SolidBrush($ColorTextMain)
    $subBrush = New-Object System.Drawing.SolidBrush($ColorTextDim)

    $mainSize = $g.MeasureString($script:dropText, $mainFont)
    $g.DrawString($script:dropText, $mainFont, $mainBrush, [float](($s.Width - $mainSize.Width) / 2), 50)

    $subSize = $g.MeasureString($script:dropSubText, $subFont)
    $g.DrawString($script:dropSubText, $subFont, $subBrush, [float](($s.Width - $subSize.Width) / 2), 78)

    $mainFont.Dispose(); $subFont.Dispose(); $mainBrush.Dispose(); $subBrush.Dispose()
})

$dropPanel.Add_MouseEnter({ $script:dropHover = $true; $dropPanel.Invalidate() })
$dropPanel.Add_MouseLeave({ $script:dropHover = $false; $dropPanel.Invalidate() })

$dropPanel.Add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Title = "Select a Psych Engine chart"
    $dlg.Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*"
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        Load-ChartFile $dlg.FileName
    }
})

$dropPanel.Add_DragEnter({
    param($s, $e)
    if ($e.Data.GetDataPresent([System.Windows.Forms.DataFormats]::FileDrop)) {
        $e.Effect = [System.Windows.Forms.DragDropEffects]::Copy
        $script:dropHover = $true
        $dropPanel.Invalidate()
    } else {
        $e.Effect = [System.Windows.Forms.DragDropEffects]::None
    }
})
$dropPanel.Add_DragLeave({ $script:dropHover = $false; $dropPanel.Invalidate() })
$dropPanel.Add_DragDrop({
    param($s, $e)
    $script:dropHover = $false
    $files = $e.Data.GetData([System.Windows.Forms.DataFormats]::FileDrop)
    if ($files -and $files.Count -gt 0) { Load-ChartFile $files[0] }
    $dropPanel.Invalidate()
})

$form.Controls.Add($dropPanel)

# --- Options panel: mustHitSection handling ---
$optionsPanel = New-Object System.Windows.Forms.Panel
$optionsPanel.Location = New-Object System.Drawing.Point(20, 204)
$optionsPanel.Size = New-Object System.Drawing.Size(420, 96)
$optionsPanel.BackColor = $ColorPanel
$optionsPanel.Add_Paint({
    param($s, $e)
    $pen = New-Object System.Drawing.Pen($ColorBorder, 1)
    $e.Graphics.DrawRectangle($pen, 0, 0, $s.Width - 1, $s.Height - 1)
    $pen.Dispose()
})
$form.Controls.Add($optionsPanel)

$optHeader = New-Object System.Windows.Forms.Label
$optHeader.Text = "MUSTHITSECTION HANDLING"
$optHeader.Font = New-Object System.Drawing.Font('Segoe UI', 7.5, [System.Drawing.FontStyle]::Bold)
$optHeader.ForeColor = $ColorTextDim
$optHeader.Location = New-Object System.Drawing.Point(14, 10)
$optHeader.Size = New-Object System.Drawing.Size(390, 16)
$optionsPanel.Controls.Add($optHeader)

$musthitCombo = New-Object System.Windows.Forms.ComboBox
$musthitCombo.DropDownStyle = 'DropDownList'
$musthitCombo.FlatStyle = 'Flat'
$musthitCombo.BackColor = $ColorPanelAlt
$musthitCombo.ForeColor = $ColorTextMain
$musthitCombo.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$musthitCombo.Location = New-Object System.Drawing.Point(14, 30)
$musthitCombo.Size = New-Object System.Drawing.Size(392, 24)
[void]$musthitCombo.Items.Add("Default (preserve per-section)")
[void]$musthitCombo.Items.Add("Force All False (Recommended)")
[void]$musthitCombo.Items.Add("Force All True")
$musthitCombo.SelectedIndex = 1
$optionsPanel.Controls.Add($musthitCombo)
$script:musthitValues = @('default', 'all-false', 'all-true')

$optHint = New-Object System.Windows.Forms.Label
$optHint.Text = "Choose how sections are treated for bot alignment."
$optHint.Font = New-Object System.Drawing.Font('Segoe UI', 7.5)
$optHint.ForeColor = $ColorTextDim
$optHint.Location = New-Object System.Drawing.Point(14, 60)
$optHint.Size = New-Object System.Drawing.Size(392, 28)
$optionsPanel.Controls.Add($optHint)

# --- Convert button ---
$convertBtn = New-Object System.Windows.Forms.Button
$convertBtn.Location = New-Object System.Drawing.Point(20, 314)
$convertBtn.Size = New-Object System.Drawing.Size(420, 50)
$convertBtn.FlatStyle = 'Flat'
$convertBtn.FlatAppearance.BorderSize = 0
$convertBtn.Font = New-Object System.Drawing.Font('Segoe UI', 10.5, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($convertBtn)

function Enable-ConvertButton {
    $convertBtn.Enabled = $true
    $convertBtn.BackColor = $ColorBtn
    $convertBtn.ForeColor = [System.Drawing.Color]::White
    $convertBtn.Text = "Convert && Save"
    $convertBtn.Cursor = [System.Windows.Forms.Cursors]::Hand
}
function Disable-ConvertButton {
    $convertBtn.Enabled = $false
    $convertBtn.BackColor = $ColorBtnOff
    $convertBtn.ForeColor = $ColorBtnOffTxt
    $convertBtn.Text = "Ready for Conversion"
    $convertBtn.Cursor = [System.Windows.Forms.Cursors]::Default
}
$convertBtn.Add_MouseEnter({ if ($convertBtn.Enabled) { $convertBtn.BackColor = $ColorBtnHover } })
$convertBtn.Add_MouseLeave({ if ($convertBtn.Enabled) { $convertBtn.BackColor = $ColorBtn } })
Disable-ConvertButton

# --- Status message ---
$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Location = New-Object System.Drawing.Point(20, 378)
$statusLabel.Size = New-Object System.Drawing.Size(420, 60)
$statusLabel.Font = New-Object System.Drawing.Font('Segoe UI', 8.5)
$statusLabel.TextAlign = 'MiddleLeft'
$statusLabel.Padding = New-Object System.Windows.Forms.Padding(12, 0, 12, 0)
$statusLabel.BorderStyle = 'FixedSingle'
$statusLabel.Visible = $false
$form.Controls.Add($statusLabel)

function Show-Status {
    param([string]$Message, [string]$Type)
    $statusLabel.Text = $Message
    $statusLabel.Visible = $true
    if ($Type -eq 'error') {
        $statusLabel.BackColor = $ColorErrBg
        $statusLabel.ForeColor = $ColorErr
        $openLink.Visible = $false
    } else {
        $statusLabel.BackColor = $ColorOkBg
        $statusLabel.ForeColor = $ColorOk
    }
}

# --- Open output folder link (shown after a successful conversion) ---
$openLink = New-Object System.Windows.Forms.LinkLabel
$openLink.Location = New-Object System.Drawing.Point(20, 442)
$openLink.Size = New-Object System.Drawing.Size(420, 18)
$openLink.Text = "Open output folder"
$openLink.TextAlign = 'MiddleCenter'
$openLink.LinkColor = $ColorAccent
$openLink.ActiveLinkColor = $ColorAccent
$openLink.VisitedLinkColor = $ColorAccent
$openLink.LinkBehavior = 'HoverUnderline'
$openLink.BackColor = $ColorBg
$openLink.Visible = $false
$openLink.Add_LinkClicked({
    if ($script:lastOutputFolder -and (Test-Path $script:lastOutputFolder)) {
        Start-Process explorer.exe -ArgumentList "`"$script:lastOutputFolder`""
    }
})
$form.Controls.Add($openLink)

# --- Footer note ---
$footerLabel = New-Object System.Windows.Forms.Label
$footerLabel.Text = "Notes are automatically cleaned to [time, direction, length] format."
$footerLabel.Font = New-Object System.Drawing.Font('Segoe UI', 7.5)
$footerLabel.ForeColor = $ColorTextDim
$footerLabel.TextAlign = 'MiddleCenter'
$footerLabel.Location = New-Object System.Drawing.Point(20, 470)
$footerLabel.Size = New-Object System.Drawing.Size(420, 40)
$form.Controls.Add($footerLabel)

# =====================================================================
#  File loading
# =====================================================================
$script:originalJsonText = $null
$script:originalFileName = "chart.json"

function Load-ChartFile {
    param([string]$Path)
    try {
        if (-not (Test-Path -LiteralPath $Path)) { throw "File not found." }
        $raw = Get-Content -LiteralPath $Path -Raw -ErrorAction Stop
        [void](Get-PsychData $raw)   # validate shape, same rules as main.js

        $script:originalJsonText = $raw
        $script:originalFileName = Split-Path -Leaf $Path
        $script:dropText = $script:originalFileName
        $dropPanel.Invalidate()

        $openLink.Visible = $false
        Show-Status "Chart loaded! Ready to clean for FNFBOT." 'success'
        Enable-ConvertButton
    } catch {
        $script:originalJsonText = $null
        $script:dropText = "Click or Drag JSON here"
        $dropPanel.Invalidate()
        Show-Status ("Error: " + $_.Exception.Message) 'error'
        Disable-ConvertButton
    }
}

# =====================================================================
#  Conversion (mirrors main.js step for step)
# =====================================================================
$convertBtn.Add_Click({
    if (-not $script:originalJsonText) { return }
    try {
        $cleanSong = Get-PsychData $script:originalJsonText   # fresh parse = clean clone

        # 1. Strip events (FNFBOT crashes on non-numeric note data)
        if (Test-HasProperty $cleanSong 'events') {
            Set-PropertySafe $cleanSong 'events' @()
        }

        # 2. Process sections and notes
        $musthitMode = $script:musthitValues[$musthitCombo.SelectedIndex]

        if ($cleanSong.notes -is [array]) {
            foreach ($section in $cleanSong.notes) {

                # Support both "sectionNotes" wrapped sections and raw notes arrays
                $hasSectionNotes = (Test-HasProperty $section 'sectionNotes') -and ($null -ne $section.sectionNotes)
                $hasNotesProp    = (Test-HasProperty $section 'notes') -and ($null -ne $section.notes)

                if ($hasSectionNotes) { $notesArray = @($section.sectionNotes) }
                elseif ($hasNotesProp) { $notesArray = @($section.notes) }
                else { $notesArray = @() }

                # Determine target mustHitSection for this section based on mode
                if ($musthitMode -eq 'all-false') { $targetMustHit = $false }
                elseif ($musthitMode -eq 'all-true') { $targetMustHit = $true }
                else {
                    if ((Test-HasProperty $section 'mustHitSection') -and ($null -ne $section.mustHitSection)) {
                        $targetMustHit = $section.mustHitSection
                    } else {
                        $targetMustHit = $true
                    }
                }

                $newNotes = New-Object System.Collections.ArrayList

                foreach ($note in $notesArray) {
                    $noteArr = @($note)

                    # Skip notes marked as Hurt Note in the 4th element
                    $marker = $null
                    if ($noteArr.Count -ge 4) { $marker = $noteArr[3] }

                    $skip = $false
                    if ($marker -is [string]) {
                        if ($marker.ToLower().Contains('hurt')) { $skip = $true }
                    } elseif ($marker -is [System.Management.Automation.PSCustomObject]) {
                        if ((Test-HasProperty $marker 'noteType') -and ($marker.noteType -is [string]) -and
                            ($marker.noteType.ToLower().Contains('hurt'))) {
                            $skip = $true
                        }
                    }
                    if ($skip) { continue }

                    # note expected as [time, direction, length, ...]
                    $time = ConvertTo-NumberOrZero $noteArr[0]
                    $dir  = ConvertTo-NumberOrZero $noteArr[1]
                    $len  = ConvertTo-NumberOrZero $noteArr[2]

                    # Forced Alignment for FNFBOT: if targetMustHit is false, swap columns
                    if ($targetMustHit -eq $false) {
                        if ($dir -ge 4) { $dir = $dir - 4 } else { $dir = $dir + 4 }
                    }

                    [void]$newNotes.Add(@($time, $dir, $len))
                }

                $newNotesArray = @($newNotes.ToArray())

                if ($hasSectionNotes) { Set-PropertySafe $section 'sectionNotes' $newNotesArray }
                elseif ($hasNotesProp) { Set-PropertySafe $section 'notes' $newNotesArray }
                else { Set-PropertySafe $section 'sectionNotes' $newNotesArray }

                # Set the section flag according to chosen mode
                if ($musthitMode -eq 'all-false') { Set-PropertySafe $section 'mustHitSection' $false }
                elseif ($musthitMode -eq 'all-true') { Set-PropertySafe $section 'mustHitSection' $true }
                else { Set-PropertySafe $section 'mustHitSection' $targetMustHit }
            }
        }

        # 4. Final Kade-like structure wrapping
        $finalOutput = [PSCustomObject]@{ song = $cleanSong }

        # 5. Save to .\converted\<original file name>
        $outDir = Join-Path $PSScriptRoot 'converted'
        if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }
        $outPath = Join-Path $outDir $script:originalFileName

        $jsonText = $finalOutput | ConvertTo-Json -Depth 30
        [System.IO.File]::WriteAllText($outPath, $jsonText, (New-Object System.Text.UTF8Encoding($false)))

        $script:lastOutputFolder = $outDir
        $openLink.Visible = $true
        Show-Status ("Converted! Saved to converted\" + $script:originalFileName) 'success'
    } catch {
        $openLink.Visible = $false
        Show-Status ("Conversion failed: " + $_.Exception.Message) 'error'
    }
})

# =====================================================================
#  Run
# =====================================================================
[void]$form.ShowDialog()