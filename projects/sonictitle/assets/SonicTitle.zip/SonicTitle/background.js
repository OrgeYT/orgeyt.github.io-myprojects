// Set default: font enabled on first install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get({ enabled: true }, (data) => {
    // Ensure the key exists
    chrome.storage.sync.set({ enabled: data.enabled !== false });
  });
});
