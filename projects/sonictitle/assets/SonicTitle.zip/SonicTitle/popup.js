const toggle = document.getElementById('toggle');
const status = document.getElementById('status');
const domainInput = document.getElementById('domainInput');
const addBtn = document.getElementById('addBtn');
const quickExcludeBtn = document.getElementById('quickExcludeBtn');
const domainList = document.getElementById('domainList');

function updateStatus(enabled) {
  status.textContent = enabled ? 'Font is ON' : 'Font is OFF';
  status.className = 'status ' + (enabled ? 'on' : 'off');
  toggle.checked = enabled;
}

function renderDomainList(domains) {
  if (domains.length === 0) {
    domainList.innerHTML = '<div class="empty-list">No excluded domains</div>';
    return;
  }

  domainList.innerHTML = domains.map((domain, index) => `
    <div class="domain-item">
      <span class="domain-name">${domain}</span>
      <button class="remove-btn" data-index="${index}">Remove</button>
    </div>
  `).join('');

  // Add event listeners to remove buttons
  domainList.querySelectorAll('.remove-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const index = parseInt(e.target.dataset.index);
      removeDomain(index);
    });
  });
}

function loadExcludedDomains() {
  chrome.storage.sync.get({ excludedDomains: [] }, (data) => {
    renderDomainList(data.excludedDomains);
  });
}

function cleanDomain(input) {
  let domain = input.trim().toLowerCase();
  
  // Remove protocol
  domain = domain.replace(/^https?:\/\//, '');
  
  // Remove www.
  domain = domain.replace(/^www\./, '');
  
  // Remove trailing slash and path
  domain = domain.split('/')[0];
  
  // Remove query string
  domain = domain.split('?')[0];
  
  return domain;
}

function addDomain(domainToAdd = null) {
  let domain = domainToAdd || domainInput.value.trim();
  
  if (!domain) {
    alert('Please enter a domain');
    return;
  }

  // Clean the input
  domain = cleanDomain(domain);

  // Basic domain validation
  if (!/^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*\.[a-z]{2,}$/.test(domain)) {
    alert('Please enter a valid domain (e.g., claude.ai)');
    return;
  }

  chrome.storage.sync.get({ excludedDomains: [] }, (data) => {
    const domains = data.excludedDomains;
    if (domains.includes(domain)) {
      alert('Domain already in exclusion list');
      return;
    }

    domains.push(domain);
    chrome.storage.sync.set({ excludedDomains: domains }, () => {
      renderDomainList(domains);
      domainInput.value = '';
      
      // Tell all tabs about the update
      chrome.tabs.query({}, (tabs) => {
        for (const tab of tabs) {
          if (tab.id) {
            chrome.tabs.sendMessage(tab.id, {
              type: 'SONIC_EXCLUSIONS_UPDATED',
              excludedDomains: domains
            }).catch(() => {});
          }
        }
      });
    });
  });
}

function removeDomain(index) {
  chrome.storage.sync.get({ excludedDomains: [] }, (data) => {
    const domains = data.excludedDomains;
    domains.splice(index, 1);
    chrome.storage.sync.set({ excludedDomains: domains }, () => {
      renderDomainList(domains);
      
      // Tell all tabs about the update
      chrome.tabs.query({}, (tabs) => {
        for (const tab of tabs) {
          if (tab.id) {
            chrome.tabs.sendMessage(tab.id, {
              type: 'SONIC_EXCLUSIONS_UPDATED',
              excludedDomains: domains
            }).catch(() => {});
          }
        }
      });
    });
  });
}

function getCurrentTabDomain(callback) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length > 0) {
      const url = tabs[0].url;
      if (url) {
        const domain = cleanDomain(url);
        callback(domain);
      } else {
        callback(null);
      }
    } else {
      callback(null);
    }
  });
}

// Load current state
chrome.storage.sync.get({ enabled: true }, (data) => {
  updateStatus(!!data.enabled);
});

loadExcludedDomains();

// Get current tab domain and update button
getCurrentTabDomain((domain) => {
  if (domain) {
    quickExcludeBtn.textContent = `Exclude ${domain}`;
    quickExcludeBtn.dataset.domain = domain;
  } else {
    quickExcludeBtn.disabled = true;
    quickExcludeBtn.textContent = 'Unable to detect domain';
  }
});

// Toggle handler
toggle.addEventListener('change', () => {
  const enabled = toggle.checked;
  chrome.storage.sync.set({ enabled }, () => {
    updateStatus(enabled);

    // Tell all tabs immediately
    chrome.tabs.query({}, (tabs) => {
      for (const tab of tabs) {
        if (tab.id) {
          chrome.tabs.sendMessage(tab.id, {
            type: 'SONIC_FONT_TOGGLE',
            enabled
          }).catch(() => {});
        }
      }
    });
  });
});

// Quick exclude button
quickExcludeBtn.addEventListener('click', () => {
  const domain = quickExcludeBtn.dataset.domain;
  if (domain) {
    addDomain(domain);
    quickExcludeBtn.textContent = 'Added to exclusion list!';
    setTimeout(() => {
      quickExcludeBtn.textContent = `Exclude ${domain}`;
    }, 2000);
  }
});

// Add domain button
addBtn.addEventListener('click', () => addDomain());

// Add on Enter key
domainInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    addDomain();
  }
});
