// Sonic Title Font – content script v1.4
// Applies pixel font to text + Markdown.
// Aggressively protects Material Icons / icon fonts (CSS + JS runtime fix).
// Supports domain exclusion list.

const STYLE_ID = 'sonic-title-font-style';
const FONT_URL = chrome.runtime.getURL('fonts/SonicTitle.ttf');

const ICON_FONT_STACK = `'Material Icons', 'Material Icons Outlined', 'Material Icons Round',
  'Material Icons Sharp', 'Material Icons Two Tone',
  'Material Symbols Outlined', 'Material Symbols Rounded', 'Material Symbols Sharp',
  'Font Awesome 6 Free', 'Font Awesome 5 Free', 'FontAwesome',
  'Bootstrap Icons', 'Glyphicons Halflings', inherit`;

function getCurrentDomain() {
  return window.location.hostname;
}

function isExcluded(excludedDomains) {
  const currentDomain = getCurrentDomain();
  return excludedDomains.includes(currentDomain);
}

function createStyle() {
  const style = document.createElement('style');
  style.id = STYLE_ID;
  style.setAttribute('data-sonic-font', '1');
  style.textContent = `
    @font-face {
      font-family: 'Sonic Title';
      src: url('${FONT_URL}') format('truetype');
      font-weight: normal;
      font-style: normal;
      font-display: swap;
    }

    /* 1. Apply Sonic Title broadly */
    html body,
    html body *:not(script):not(style):not(noscript):not(svg):not(path):not(canvas) {
      font-family: 'Sonic Title', system-ui, -apple-system, BlinkMacSystemFont,
                   'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif !important;
    }

    code, pre, kbd, samp, tt, var,
    .hljs, .highlight, .CodeMirror, .cm-editor, .token,
    [class*="code"], [class*="mono"] {
      font-family: 'Sonic Title', ui-monospace, SFMono-Regular, Menlo, Monaco,
                   Consolas, 'Liberation Mono', monospace !important;
    }

    /* 2. CSS-level icon protection (first line of defence) */
    .material-icons,
    .material-icons-outlined,
    .material-icons-round,
    .material-icons-sharp,
    .material-icons-two-tone,
    .material-symbols-outlined,
    .material-symbols-rounded,
    .material-symbols-sharp,
    .material-symbols-filled,
    [class*="material-icons"],
    [class*="material-symbols"],
    .fa, .fas, .far, .fal, .fad, .fab,
    .fa-solid, .fa-regular, .fa-brands, .fa-light, .fa-thin,
    [class*="fa-"],
    .bi, .glyphicon, .icon, .ico,
    [class*="icon-"], [class^="icon-"],
    .mdc-list-item__graphic,
    .mdc-icon-button,
    .mdc-button__icon,
    .mdc-fab__icon,
    .mdc-top-app-bar__navigation-icon,
    svg, svg * {
      font-family: ${ICON_FONT_STACK} !important;
      -webkit-font-feature-settings: 'liga' !important;
      font-feature-settings: 'liga' !important;
    }

    /* Force classic Material Icons properties so ligatures work */
    .material-icons,
    [class*="material-icons"],
    i.material-icons,
    span.material-icons {
      font-family: 'Material Icons' !important;
      font-weight: normal !important;
      font-style: normal !important;
      font-size: inherit;
      letter-spacing: normal !important;
      text-transform: none !important;
      display: inline-block;
      white-space: nowrap !important;
      word-wrap: normal !important;
      direction: ltr !important;
      -webkit-font-feature-settings: 'liga' !important;
      font-feature-settings: 'liga' !important;
      -webkit-font-smoothing: antialiased !important;
    }
  `;
  return style;
}

function isIconElement(el) {
  if (!el || el.nodeType !== 1) return false;
  const tag = el.tagName;
  if (tag === 'SVG' || tag === 'PATH' || tag === 'CANVAS') return true;

  const cls = (el.className && typeof el.className === 'string') ? el.className.toLowerCase() : '';
  if (
    cls.includes('material-icons') ||
    cls.includes('material-symbols') ||
    cls.includes('fa-') ||
    cls.includes('fa ') ||
    cls.startsWith('fa ') ||
    cls.includes('glyphicon') ||
    cls.includes('bi-') ||
    cls.includes('icon-') ||
    cls.includes('mdc-list-item__graphic') ||
    cls.includes('mdc-icon-button') ||
    cls.includes('mdc-button__icon')
  ) return true;

  // Short single-token text that looks like an icon name
  // (Material Icons ligatures are usually one word / snake_case)
  const text = (el.textContent || '').trim();
  if (
    text.length > 0 &&
    text.length < 40 &&
    !text.includes(' ') &&
    /^[a-z0-9_.-]+$/i.test(text) &&
    (tag === 'I' || tag === 'SPAN' || tag === 'BUTTON' || el.getAttribute('aria-hidden') === 'true')
  ) {
    // Common icon name patterns
    if (
      /^(arrow|menu|close|add|remove|delete|trash|edit|create|upload|download|folder|file|image|video|audio|link|share|search|home|person|settings|check|clear|more|expand|chevron|star|favorite|heart|info|warning|error|help|lock|unlock|visibility|sort|filter|refresh|sync|cloud|mail|send|attach|content_copy|content_cut|content_paste|undo|redo|bold|italic|underline|code|list|grid|view|dashboard|notifications|account|logout|login|exit|open_in_new|launch|play|pause|stop|skip|volume|mic|camera|photo|videocam|map|place|schedule|event|today|date|time|timer|alarm|build|code|bug|extension|widgets|tune|palette|brush|format|text|title|subject|notes|description|article|book|bookmark|label|flag|push_pin|location|navigation|directions|commute|flight|train|directions_car|local|store|shopping|payment|credit_card|account_balance|work|school|science|sports|fitness|restaurant|local_cafe|hotel|beach|park|museum|theater|music|movie|tv|radio|podcast|gamepad|casino|pets|emoji|mood|sentiment|thumb|favorite|grade|star_border|star_half)/i.test(text) ||
      text.includes('_') || text.includes('-')
    ) {
      return true;
    }
  }
  return false;
}

function protectIcons(root = document) {
  const candidates = root.querySelectorAll(
    'i, span, button, [class*="material-icons"], [class*="material-symbols"], ' +
    '[class*="fa-"], [class*="icon"], .mdc-list-item__graphic, .mdc-icon-button, ' +
    '.mdc-button__icon, .mdc-top-app-bar__navigation-icon, [aria-hidden="true"]'
  );

  for (const el of candidates) {
    if (isIconElement(el)) {
      // Inline style with !important beats almost everything
      el.style.setProperty('font-family', ICON_FONT_STACK, 'important');
      el.style.setProperty('-webkit-font-feature-settings', "'liga'", 'important');
      el.style.setProperty('font-feature-settings', "'liga'", 'important');
      // Extra Material Icons properties
      if ((el.className || '').toLowerCase().includes('material-icons') ||
          (el.className || '').toLowerCase().includes('material-symbols')) {
        el.style.setProperty('font-family', "'Material Icons', 'Material Symbols Outlined'", 'important');
        el.style.setProperty('font-weight', 'normal', 'important');
        el.style.setProperty('font-style', 'normal', 'important');
        el.style.setProperty('letter-spacing', 'normal', 'important');
        el.style.setProperty('text-transform', 'none', 'important');
        el.style.setProperty('white-space', 'nowrap', 'important');
      }
    }
  }
}

function enableFont() {
  disableFont();
  const style = createStyle();
  (document.head || document.documentElement).appendChild(style);
  protectIcons();
}

function disableFont() {
  const el = document.getElementById(STYLE_ID);
  if (el) el.remove();
}

function shouldApplyFont(callback) {
  chrome.storage.sync.get({ enabled: true, excludedDomains: [] }, (data) => {
    const shouldApply = data.enabled && !isExcluded(data.excludedDomains);
    callback(shouldApply);
  });
}

// Initial
shouldApplyFont((shouldApply) => {
  if (shouldApply) enableFont();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'sync') {
    shouldApplyFont((shouldApply) => {
      if (shouldApply) enableFont();
      else disableFont();
    });
  }
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'SONIC_FONT_TOGGLE') {
    if (msg.enabled) {
      shouldApplyFont((shouldApply) => {
        if (shouldApply) enableFont();
        else disableFont();
      });
    } else {
      disableFont();
    }
  } else if (msg.type === 'SONIC_EXCLUSIONS_UPDATED') {
    if (isExcluded(msg.excludedDomains)) {
      disableFont();
    } else {
      chrome.storage.sync.get({ enabled: true }, (data) => {
        if (data.enabled) enableFont();
      });
    }
  }
});

// Keep style alive + protect newly added icons (SPA / dynamic lists)
const observer = new MutationObserver((mutations) => {
  let needStyle = !document.getElementById(STYLE_ID);
  let needProtect = false;

  for (const m of mutations) {
    if (m.type === 'childList' && m.addedNodes.length) {
      needProtect = true;
      break;
    }
  }

  shouldApplyFont((shouldApply) => {
    if (!shouldApply) return;
    if (needStyle) enableFont();
    else if (needProtect) protectIcons();
  });
});

observer.observe(document.documentElement, {
  childList: true,
  subtree: true
});
