Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Colors for Dark Theme
$darkBack = [System.Drawing.Color]::FromArgb(45, 45, 48)
$lightFore = [System.Drawing.Color]::FromArgb(240, 240, 240)
$accentColor = [System.Drawing.Color]::FromArgb(0, 122, 204)

# Setup Form
$form = New-Object System.Windows.Forms.Form
$form.Text = "VBS Designer Pro [Advanced Loader]"
$form.Size = New-Object System.Drawing.Size(750, 550)
$form.StartPosition = "CenterScreen"
$form.BackColor = $darkBack
$form.ForeColor = $lightFore

# Data Grid
$grid = New-Object System.Windows.Forms.DataGridView
$grid.Size = New-Object System.Drawing.Size(710, 300)
$grid.Location = New-Object System.Drawing.Point(10, 10)
$grid.AutoGenerateColumns = $false
$grid.AllowUserToAddRows = $true
$grid.BackgroundColor = $darkBack
$grid.DefaultCellStyle.BackColor = $darkBack
$grid.DefaultCellStyle.ForeColor = $lightFore
$grid.ColumnHeadersDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
$grid.ColumnHeadersDefaultCellStyle.ForeColor = $lightFore
$grid.EnableHeadersVisualStyles = $false

# Columns
$colMsg = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colMsg.HeaderText = "Message"
$colMsg.Name = "Msg"
$colMsg.Width = 200
$grid.Columns.Add($colMsg)

$colTitle = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colTitle.HeaderText = "Title"
$colTitle.Name = "Title"
$colTitle.Width = 120
$grid.Columns.Add($colTitle)

$colButtons = New-Object System.Windows.Forms.DataGridViewComboBoxColumn
$colButtons.HeaderText = "Buttons"
$colButtons.Name = "Buttons"
$colButtons.Items.AddRange("OK", "OKCancel", "AbortRetryIgnore", "YesNoCancel", "YesNo", "RetryCancel")
$grid.Columns.Add($colButtons)

$colIcon = New-Object System.Windows.Forms.DataGridViewComboBoxColumn
$colIcon.HeaderText = "Icon"
$colIcon.Name = "Icon"
$colIcon.Items.AddRange("None", "Critical", "Question", "Exclamation", "Information")
$grid.Columns.Add($colIcon)

$form.Controls.Add($grid)

# Paths
$scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$saveDir = Join-Path $scriptDir "saves"
$exportDir = Join-Path $scriptDir "exports"
foreach($d in @($saveDir, $exportDir)) { if (!(Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null } }

# Buttons
$btnSaveJson = New-Object System.Windows.Forms.Button -Property @{Text="Save JSON"; Location="10,450"; Size="150,40"}
$btnLoadJson = New-Object System.Windows.Forms.Button -Property @{Text="Load File..."; Location="170,450"; Size="150,40"}
$btnExport = New-Object System.Windows.Forms.Button -Property @{Text="EXPORT VBS"; Location="570,450"; Size="150,40"; BackColor=$accentColor; FlatStyle="Flat"; ForeColor="White"}

# Events
$btnSaveJson.Add_Click({
    $saveDialog = New-Object System.Windows.Forms.SaveFileDialog
    $saveDialog.InitialDirectory = $saveDir
    $saveDialog.Filter = "JSON Files (*.json)|*.json"
    if ($saveDialog.ShowDialog() -eq "OK") {
        $data = foreach($row in $grid.Rows) { if($row.Cells[0].Value) { [PSCustomObject]@{Msg=$row.Cells[0].Value; Title=$row.Cells[1].Value; Buttons=$row.Cells[2].Value; Icon=$row.Cells[3].Value} } }
        $data | ConvertTo-Json | Out-File $saveDialog.FileName
        [System.Windows.Forms.MessageBox]::Show("Project saved!")
    }
})

$btnLoadJson.Add_Click({
    $openDialog = New-Object System.Windows.Forms.OpenFileDialog
    $openDialog.InitialDirectory = $saveDir
    $openDialog.Filter = "JSON Files (*.json)|*.json"
    if ($openDialog.ShowDialog() -eq "OK") {
        $grid.Rows.Clear()
        $json = Get-Content $openDialog.FileName -Raw | ConvertFrom-Json
        foreach($item in $json) { $grid.Rows.Add($item.Msg, $item.Title, $item.Buttons, $item.Icon) }
    }
})

$btnExport.Add_Click({
    $firstRow = $grid.Rows | Where-Object { $_.Cells["Msg"].Value } | Select-Object -First 1
    $title = if ($firstRow -and $firstRow.Cells["Title"].Value) { $firstRow.Cells["Title"].Value } else { "Untitled" }
    $fileName = Join-Path $exportDir ("vbsscript-" + ($title -replace '[\\/:"*?<>|]', '') + ".vbs")
    
    $scriptContent = foreach($row in $grid.Rows) { 
        if($row.Cells["Msg"].Value) {
            $b = switch($row.Cells["Buttons"].Value) { "OKCancel"{1}; "AbortRetryIgnore"{2}; "YesNoCancel"{3}; "YesNo"{4}; "RetryCancel"{5}; Default{0} }
            $i = switch($row.Cells["Icon"].Value) { "Critical"{16}; "Question"{32}; "Exclamation"{48}; "Information"{64}; Default{0} }
            "MsgBox `"$($row.Cells[0].Value)`", ($b + $i), `"$($row.Cells[1].Value)`""
        }
    }
    $scriptContent | Out-File $fileName
    [System.Windows.Forms.MessageBox]::Show("Exported to: $fileName")
})

$form.Controls.AddRange(@($btnSaveJson, $btnLoadJson, $btnExport))
$form.ShowDialog()