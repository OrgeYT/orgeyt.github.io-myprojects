# CursorToggle GUI - main.ps1
# Lightweight WinForms window to switch between Catto Boi and Windows Default

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ErrorActionPreference = "Stop"

# ── Paths ──────────────────────────────────────────────────────────────────
$ScriptDir     = Split-Path -Parent $MyInvocation.MyCommand.Path
$CursorPackDir = Join-Path $ScriptDir "Catto Boi"

$RegHive    = [Microsoft.Win32.Registry]::CurrentUser
$RegKeyPath = "Control Panel\Cursors"

# Exact modern Windows Default (from working registry)
$DefaultExpandValues = [ordered]@{
    "Arrow"       = "%SystemRoot%\cursors\aero_arrow.cur"
    "Help"        = "%SystemRoot%\cursors\aero_helpsel.cur"
    "AppStarting" = "%SystemRoot%\cursors\aero_working.ani"
    "Wait"        = "%SystemRoot%\cursors\aero_busy.ani"
    "No"          = "%SystemRoot%\cursors\aero_unavail.cur"
    "NWPen"       = "%SystemRoot%\cursors\aero_pen.cur"
    "SizeNS"      = "%SystemRoot%\cursors\aero_ns.cur"
    "SizeWE"      = "%SystemRoot%\cursors\aero_ew.cur"
    "SizeNWSE"    = "%SystemRoot%\cursors\aero_nwse.cur"
    "SizeNESW"    = "%SystemRoot%\cursors\aero_nesw.cur"
    "SizeAll"     = "%SystemRoot%\cursors\aero_move.cur"
    "UpArrow"     = "%SystemRoot%\cursors\aero_up.cur"
    "Hand"        = "%SystemRoot%\cursors\aero_link.cur"
    "Pin"         = "%SystemRoot%\cursors\aero_pin.cur"
    "Person"      = "%SystemRoot%\cursors\aero_person.cur"
}
$EmptyDefaultRoles = @("Crosshair", "IBeam")

# ── Cursor helpers ─────────────────────────────────────────────────────────
function Refresh-Cursors {
    $signature = @'
[DllImport("user32.dll", SetLastError = true)]
public static extern bool SystemParametersInfo(uint uiAction, uint uiParam, IntPtr pvParam, uint fWinIni);
'@
    try {
        $type = Add-Type -MemberDefinition $signature -Name WinAPICursor -Namespace CursorToggle -PassThru -ErrorAction Stop
    } catch {
        $type = [CursorToggle.WinAPICursor]
    }
    $SPI_SETCURSORS = 0x0057
    $flags = 0x01 -bor 0x02   # SPIF_UPDATEINIFILE | SPIF_SENDCHANGE
    $ok = $type::SystemParametersInfo($SPI_SETCURSORS, 0, [IntPtr]::Zero, $flags)
    if (-not $ok) {
        [void]$type::SystemParametersInfo($SPI_SETCURSORS, 0, [IntPtr]::Zero, 0)
    }
}

function Open-CursorsKey {
    $key = $RegHive.OpenSubKey($RegKeyPath, $true)
    if ($null -eq $key) { throw "Cannot open HKCU\$RegKeyPath" }
    return $key
}

function Find-CrsFile {
    if (-not (Test-Path -LiteralPath $CursorPackDir)) {
        throw "Cursor pack folder not found:`n$CursorPackDir"
    }
    $crs = @(Get-ChildItem -LiteralPath $CursorPackDir -Filter "*.crs" -File -ErrorAction SilentlyContinue)
    if ($crs.Count -eq 0) { throw "No .crs file found in:`n$CursorPackDir" }
    return $crs[0].FullName
}

function Parse-CrsFile {
    param([string]$Path)
    $utf8 = New-Object System.Text.UTF8Encoding $false
    $bytes = [System.IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        $content = $utf8.GetString($bytes, 3, $bytes.Length - 3)
    } else {
        $content = $utf8.GetString($bytes)
    }
    $map = [ordered]@{}
    $section = $null
    foreach ($line in ($content -split "`r?`n")) {
        $line = $line.Trim()
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        if ($line -match '^\[(.+)\]$') { $section = $Matches[1].Trim(); continue }
        if ($null -ne $section -and $line -match '^Path\s*=\s*(.+)$') {
            $map[$section] = $Matches[1].Trim()
            $section = $null
        }
    }
    return $map
}

function Apply-CattoBoi {
    $crsPath  = Find-CrsFile
    $mappings = Parse-CrsFile -Path $crsPath
    if ($mappings.Count -eq 0) { throw "No mappings in CRS file." }

    $missing = @()
    $resolved = [ordered]@{}
    foreach ($role in $mappings.Keys) {
        $fp = Join-Path $CursorPackDir $mappings[$role]
        if (-not (Test-Path -LiteralPath $fp)) {
            $missing += "[$role] -> $($mappings[$role])"
        } else {
            $resolved[$role] = (Resolve-Path -LiteralPath $fp).Path
        }
    }
    if ($missing.Count -gt 0) {
        throw ("Missing cursor files:`n" + ($missing -join "`n"))
    }

    $key = Open-CursorsKey
    try {
        foreach ($role in $resolved.Keys) {
            $key.SetValue($role, $resolved[$role], [Microsoft.Win32.RegistryValueKind]::String)
        }
        $key.SetValue("(Default)", "", [Microsoft.Win32.RegistryValueKind]::String)
        $key.SetValue("Scheme Source", 1, [Microsoft.Win32.RegistryValueKind]::DWord)
    } finally {
        $key.Close()
    }
    Refresh-Cursors
}

function Apply-SystemDefault {
    $key = Open-CursorsKey
    try {
        foreach ($role in $DefaultExpandValues.Keys) {
            $key.SetValue($role, $DefaultExpandValues[$role], [Microsoft.Win32.RegistryValueKind]::ExpandString)
        }
        foreach ($role in $EmptyDefaultRoles) {
            $key.SetValue($role, "", [Microsoft.Win32.RegistryValueKind]::ExpandString)
        }
        $key.SetValue("(Default)", "Windows Default", [Microsoft.Win32.RegistryValueKind]::String)
        $key.SetValue("Scheme Source", 2, [Microsoft.Win32.RegistryValueKind]::DWord)
    } finally {
        $key.Close()
    }
    Refresh-Cursors
}

# ── GUI ────────────────────────────────────────────────────────────────────
$form = New-Object System.Windows.Forms.Form
$form.Text            = "CursorToggle"
$form.Size            = New-Object System.Drawing.Size(320, 200)
$form.StartPosition   = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox     = $false
$form.MinimizeBox     = $true
$form.TopMost         = $false
$form.ShowInTaskbar   = $true
$form.BackColor       = [System.Drawing.Color]::FromArgb(32, 32, 32)
$form.Font            = New-Object System.Drawing.Font("Segoe UI", 10)

$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Text      = "Ready"
$lblStatus.ForeColor = [System.Drawing.Color]::LightGray
$lblStatus.AutoSize  = $false
$lblStatus.TextAlign = "MiddleCenter"
$lblStatus.Size      = New-Object System.Drawing.Size(280, 28)
$lblStatus.Location  = New-Object System.Drawing.Point(12, 16)
$form.Controls.Add($lblStatus)

$btnCatto = New-Object System.Windows.Forms.Button
$btnCatto.Text      = "Catto Boi"
$btnCatto.Size      = New-Object System.Drawing.Size(280, 40)
$btnCatto.Location  = New-Object System.Drawing.Point(12, 55)
$btnCatto.FlatStyle = "Flat"
$btnCatto.BackColor = [System.Drawing.Color]::FromArgb(70, 130, 180)
$btnCatto.ForeColor = [System.Drawing.Color]::White
$btnCatto.FlatAppearance.BorderSize = 0
$form.Controls.Add($btnCatto)

$btnDefault = New-Object System.Windows.Forms.Button
$btnDefault.Text      = "System Default"
$btnDefault.Size      = New-Object System.Drawing.Size(280, 40)
$btnDefault.Location  = New-Object System.Drawing.Point(12, 105)
$btnDefault.FlatStyle = "Flat"
$btnDefault.BackColor = [System.Drawing.Color]::FromArgb(90, 90, 90)
$btnDefault.ForeColor = [System.Drawing.Color]::White
$btnDefault.FlatAppearance.BorderSize = 0
$form.Controls.Add($btnDefault)

function Set-Busy {
    param([bool]$Busy, [string]$Message = "Ready")
    $btnCatto.Enabled   = -not $Busy
    $btnDefault.Enabled = -not $Busy
    $lblStatus.Text     = $Message
    if ($Busy) {
        $lblStatus.ForeColor = [System.Drawing.Color]::Orange
    } else {
        $lblStatus.ForeColor = [System.Drawing.Color]::LightGreen
    }
    [System.Windows.Forms.Application]::DoEvents()
}

$btnCatto.Add_Click({
    try {
        Set-Busy $true "Applying Catto Boi..."
        Apply-CattoBoi
        Set-Busy $false "Catto Boi applied"
    } catch {
        Set-Busy $false "Error: $($_.Exception.Message)"
        $lblStatus.ForeColor = [System.Drawing.Color]::Salmon
    }
})

$btnDefault.Add_Click({
    try {
        Set-Busy $true "Restoring System Default..."
        Apply-SystemDefault
        Set-Busy $false "System Default restored"
    } catch {
        Set-Busy $false "Error: $($_.Exception.Message)"
        $lblStatus.ForeColor = [System.Drawing.Color]::Salmon
    }
})

# Welcome popup — shown once before the main window
$welcome = @"
Created by Grok
Catto Boi cursor pack by Mango-ki
Prompted by OrgeYT

If this is your first time using a custom cursor, don't worry, it's completely safe!

Switching between the Catto Boi cursor and the Windows default cursor is almost instant, so you can switch back and forth whenever you want.

This window can stay running in the background for hours without causing noticeable RAM or CPU usage.
"@

[System.Windows.Forms.MessageBox]::Show(
    $welcome,
    "CursorToggle",
    [System.Windows.Forms.MessageBoxButtons]::OK,
    [System.Windows.Forms.MessageBoxIcon]::Information
) | Out-Null

# Keep the process lightweight — just the message loop, no timers
[void]$form.ShowDialog()
