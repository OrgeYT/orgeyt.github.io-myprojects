
# CursorToggle GUI - main.ps1
# Cursor pack manager + live cursor inspector/test window
# No startup popup

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ErrorActionPreference = "Stop"

# ── Paths ──────────────────────────────────────────────────────────────────

$ScriptDir  = Split-Path -Parent $MyInvocation.MyCommand.Path
$ModsDir    = Join-Path $ScriptDir "mods"
$ErrorsDir  = Join-Path $ScriptDir "errors"
$ExportsDir = Join-Path $ScriptDir "exports"

$RegHive    = [Microsoft.Win32.Registry]::CurrentUser
$RegKeyPath = "Control Panel\Cursors"

# ── Error logging ──────────────────────────────────────────────────────────

function Write-ErrorLog {
    param(
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.ErrorRecord]$ErrorRecord,

        [string]$Context = "General"
    )

    try {
        if (-not (Test-Path -LiteralPath $ErrorsDir)) {
            New-Item -ItemType Directory -Path $ErrorsDir -Force | Out-Null
        }

        $stamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
        $safeContext = ($Context -replace '[^\w\-]', '_')
        $fileName = "${stamp}_${safeContext}.txt"
        $filePath = Join-Path $ErrorsDir $fileName

        $lines = @(
            "CursorToggle Error Log"
            "======================"
            "Time    : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
            "Context : $Context"
            "Message : $($ErrorRecord.Exception.Message)"
            ""
            "Exception type : $($ErrorRecord.Exception.GetType().FullName)"
            "FullyQualifiedErrorId : $($ErrorRecord.FullyQualifiedErrorId)"
            ""
            "Script stack trace:"
            $ErrorRecord.ScriptStackTrace
            ""
            "Exception ToString:"
            $ErrorRecord.Exception.ToString()
            ""
            "Invocation info:"
            if ($null -ne $ErrorRecord.InvocationInfo) {
                $ErrorRecord.InvocationInfo.PositionMessage
            }
        )

        $utf8 = New-Object System.Text.UTF8Encoding $false
        [System.IO.File]::WriteAllLines($filePath, $lines, $utf8)
    }
    catch {
        # Never let logging itself crash the app
    }
}

# ── Windows Default Cursor Values ──────────────────────────────────────────

# Exact Windows Aero defaults (must match files under %SystemRoot%\cursors).
# SizeNWSE uses aero_nwse.cur — NOT aero_nw.cur (wrong name caused pixelated fallback).
$DefaultExpandValues = [ordered]@{
    "Arrow"       = "%SystemRoot%\cursors\aero_arrow.cur"
    "Help"        = "%SystemRoot%\cursors\aero_helpsel.cur"
    "AppStarting" = "%SystemRoot%\cursors\aero_working.ani"
    "Wait"        = "%SystemRoot%\cursors\aero_busy.ani"
    "No"          = "%SystemRoot%\cursors\aero_unavail.cur"
    "NWPen"       = "%SystemRoot%\cursors\aero_pen.cur"
    "SizeNS"      = "%SystemRoot%\cursors\aero_ns.cur"
    "SizeWE"      = "%SystemRoot%\cursors\aero_ew.cur"
    "SizeNWSE"    = "%SystemRoot%\cursors\aero_nwse.cur"
    "SizeNESW"    = "%SystemRoot%\cursors\aero_nesw.cur"
    "SizeAll"     = "%SystemRoot%\cursors\aero_move.cur"
    "UpArrow"     = "%SystemRoot%\cursors\aero_up.cur"
    "Hand"        = "%SystemRoot%\cursors\aero_link.cur"
    "Pin"         = "%SystemRoot%\cursors\aero_pin.cur"
    "Person"      = "%SystemRoot%\cursors\aero_person.cur"
}

$EmptyDefaultRoles = @(
    "Crosshair",
    "IBeam"
)

# ── Win32 Cursor Loader ────────────────────────────────────────────────────
#
# This lets us load the ACTUAL cursor files currently assigned by Windows.
# It supports both .cur and .ani files.

if (-not ("CursorToggle.NativeMethods" -as [type])) {

    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

namespace CursorToggle
{
    public static class NativeMethods
    {
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        public static extern IntPtr LoadCursorFromFile(string lpFileName);

        [DllImport("user32.dll")]
        public static extern bool DestroyCursor(IntPtr hCursor);

        [DllImport("user32.dll")]
        public static extern bool DestroyIcon(IntPtr hIcon);

        // Draw a cursor (or icon) into an HDC. Works for both .cur and .ani
        // (draws the current/first frame of animated cursors).
        [DllImport("user32.dll")]
        public static extern bool DrawIconEx(
            IntPtr hdc,
            int xLeft,
            int yTop,
            IntPtr hIcon,
            int cxWidth,
            int cyHeight,
            int istepIfAniCur,
            IntPtr hbrFlickerFreeDraw,
            int diFlags
        );

        public const int DI_NORMAL = 0x0003;

        [DllImport("user32.dll")]
        public static extern bool SystemParametersInfo(
            uint uiAction,
            uint uiParam,
            IntPtr pvParam,
            uint fWinIni
        );
    }
}
'@
}

# ── Cursor Refresh ─────────────────────────────────────────────────────────

function Refresh-Cursors {

    $SPI_SETCURSORS = 0x0057
    $flags = 0x01 -bor 0x02

    [void][CursorToggle.NativeMethods]::SystemParametersInfo(
        $SPI_SETCURSORS,
        0,
        [IntPtr]::Zero,
        $flags
    )
}

# ── Registry ───────────────────────────────────────────────────────────────

function Open-CursorsKey {

    $key = $RegHive.OpenSubKey(
        $RegKeyPath,
        $true
    )

    if ($null -eq $key) {
        throw "Cannot open HKCU\$RegKeyPath"
    }

    return $key
}

# ── CRS Helpers ────────────────────────────────────────────────────────────

function Find-CrsFile {

    param(
        [string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        throw "Cursor pack folder not found:`n$Path"
    }

    $crs = @(
        Get-ChildItem `
            -LiteralPath $Path `
            -Filter "*.crs" `
            -File `
            -ErrorAction SilentlyContinue
    )

    if ($crs.Count -eq 0) {
        throw "No .crs file found in:`n$Path"
    }

    return $crs[0].FullName
}

function Parse-CrsFile {

    param(
        [string]$Path
    )

    $utf8 = New-Object System.Text.UTF8Encoding $false
    $bytes = [System.IO.File]::ReadAllBytes($Path)

    if (
        $bytes.Length -ge 3 -and
        $bytes[0] -eq 0xEF -and
        $bytes[1] -eq 0xBB -and
        $bytes[2] -eq 0xBF
    ) {
        $content = $utf8.GetString(
            $bytes,
            3,
            $bytes.Length - 3
        )
    }
    else {
        $content = $utf8.GetString($bytes)
    }

    $map = [ordered]@{}
    $section = $null

    foreach ($line in ($content -split "`r?`n")) {

        $line = $line.Trim()

        if ([string]::IsNullOrWhiteSpace($line)) {
            continue
        }

        if ($line -match '^\[(.+)\]$') {

            $section = $Matches[1].Trim()
            continue
        }

        if (
            $null -ne $section -and
            $line -match '^Path\s*=\s*(.+)$'
        ) {

            $map[$section] = $Matches[1].Trim()
            $section = $null
        }
    }

    return $map
}

# ── Apply Cursor Pack ──────────────────────────────────────────────────────

function Apply-CursorPack {

    param(
        [string]$ModName,
        [string]$PackDir
    )

    if (-not (Test-Path -LiteralPath $PackDir)) {
        throw "Cursor pack folder not found:`n$PackDir"
    }

    $crsPath = Find-CrsFile -Path $PackDir
    $mappings = Parse-CrsFile -Path $crsPath

    if ($mappings.Count -eq 0) {
        throw "No mappings in CRS file."
    }

    $missing = @()
    $resolved = [ordered]@{}

    foreach ($role in $mappings.Keys) {

        $fp = Join-Path `
            $PackDir `
            $mappings[$role]

        if (-not (Test-Path -LiteralPath $fp)) {

            $missing += (
                "[$role] -> $($mappings[$role])"
            )
        }
        else {

            $resolved[$role] = (
                Resolve-Path `
                    -LiteralPath $fp
            ).Path
        }
    }

    if ($missing.Count -gt 0) {

        throw (
            "Missing cursor files:`n" +
            ($missing -join "`n")
        )
    }

    $key = Open-CursorsKey

    try {

        foreach ($role in $resolved.Keys) {

            $key.SetValue(
                $role,
                $resolved[$role],
                [Microsoft.Win32.RegistryValueKind]::String
            )
        }

        $key.SetValue(
            "(Default)",
            "",
            [Microsoft.Win32.RegistryValueKind]::String
        )

        $key.SetValue(
            "Scheme Source",
            1,
            [Microsoft.Win32.RegistryValueKind]::DWord
        )
    }
    finally {
        $key.Close()
    }

    Refresh-Cursors
}

# ── Apply Windows Default ──────────────────────────────────────────────────

function Apply-SystemDefault {

    $key = Open-CursorsKey

    try {

        foreach ($role in $DefaultExpandValues.Keys) {

            $key.SetValue(
                $role,
                $DefaultExpandValues[$role],
                [Microsoft.Win32.RegistryValueKind]::ExpandString
            )
        }

        foreach ($role in $EmptyDefaultRoles) {

            $key.SetValue(
                $role,
                "",
                [Microsoft.Win32.RegistryValueKind]::ExpandString
            )
        }

        $key.SetValue(
            "(Default)",
            "Windows Default",
            [Microsoft.Win32.RegistryValueKind]::String
        )

        $key.SetValue(
            "Scheme Source",
            2,
            [Microsoft.Win32.RegistryValueKind]::DWord
        )
    }
    finally {
        $key.Close()
    }

    Refresh-Cursors
}

# ── Get Current Cursor Assignments ─────────────────────────────────────────

function Get-CurrentCursorAssignments {

    $key = $RegHive.OpenSubKey(
        $RegKeyPath,
        $false
    )

    if ($null -eq $key) {
        throw "Cannot read HKCU\$RegKeyPath"
    }

    $roles = @(
        "Arrow",
        "Help",
        "AppStarting",
        "Wait",
        "No",
        "NWPen",
        "SizeNS",
        "SizeWE",
        "SizeNWSE",
        "SizeNESW",
        "SizeAll",
        "UpArrow",
        "Hand",
        "Pin",
        "Person",
        "Crosshair",
        "IBeam"
    )

    $result = @()

    try {

        foreach ($role in $roles) {

            $rawPath = $key.GetValue(
                $role,
                "",
                [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames
            )

            if ([string]::IsNullOrWhiteSpace($rawPath)) {

                $result += [PSCustomObject]@{
                    Role = $role
                    Path = ""
                    FileName = "(none)"
                }

                continue
            }

            $expanded = [Environment]::ExpandEnvironmentVariables(
                [string]$rawPath
            )

            $result += [PSCustomObject]@{
                Role = $role
                Path = $expanded
                FileName = [System.IO.Path]::GetFileName($expanded)
            }
        }
    }
    finally {

        $key.Close()
    }

    return $result
}

# ── Create Cursor Preview ──────────────────────────────────────────────────
# Uses DrawIconEx so both .cur and .ani files render correctly.
# Icon.FromHandle on an HCURSOR is unreliable (often blank / wrong size).

function Get-CursorImage {

    param(
        [string]$Path
    )

    if (
        [string]::IsNullOrWhiteSpace($Path) -or
        -not (Test-Path -LiteralPath $Path)
    ) {
        return $null
    }

    $hCursor = [CursorToggle.NativeMethods]::LoadCursorFromFile(
        $Path
    )

    if ($hCursor -eq [IntPtr]::Zero) {
        return $null
    }

    try {

        $bitmap = [System.Drawing.Bitmap]::new(64, 64)
        $graphics = [System.Drawing.Graphics]::FromImage($bitmap)

        try {
            $graphics.Clear([System.Drawing.Color]::FromArgb(45, 45, 45))
            $graphics.InterpolationMode = (
                [System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
            )
            $graphics.PixelOffsetMode = (
                [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
            )

            $hdc = $graphics.GetHdc()
            try {
                # DI_NORMAL = 3. Draw 32x32 centered in the 64x64 bitmap.
                [void][CursorToggle.NativeMethods]::DrawIconEx(
                    $hdc,
                    16,
                    16,
                    $hCursor,
                    32,
                    32,
                    0,
                    [IntPtr]::Zero,
                    3
                )
            }
            finally {
                $graphics.ReleaseHdc($hdc)
            }
        }
        finally {
            $graphics.Dispose()
        }

        return $bitmap
    }
    catch {
        return $null
    }
    finally {
        # LoadCursorFromFile returns a private cursor handle — must free it.
        [void][CursorToggle.NativeMethods]::DestroyCursor($hCursor)
    }
}

# ── Mod Discovery ──────────────────────────────────────────────────────────

function Get-AvailableMods {

    $mods = @()

    if (-not (Test-Path -LiteralPath $ModsDir)) {
        return $mods
    }

    $modDirs = @(
        Get-ChildItem `
            -LiteralPath $ModsDir `
            -Directory `
            -ErrorAction SilentlyContinue
    )

    foreach ($dir in $modDirs) {

        $crsFiles = @(
            Get-ChildItem `
                -LiteralPath $dir.FullName `
                -Filter "*.crs" `
                -File `
                -ErrorAction SilentlyContinue
        )

        if ($crsFiles.Count -gt 0) {

            $mods += @{
                Name = $dir.Name
                Path = $dir.FullName
            }
        }
    }

    return $mods
}

# ── Cursor Test / Inspector Window ─────────────────────────────────────────

function Show-CursorTestWindow {

    $testForm = New-Object System.Windows.Forms.Form

    $testForm.Text = "CursorToggle - Cursor Inspector"
    $testForm.StartPosition = "CenterScreen"
    $testForm.Size = [System.Drawing.Size]::new(850, 720)
    $testForm.MinimumSize = [System.Drawing.Size]::new(750, 600)
    $testForm.BackColor = [System.Drawing.Color]::FromArgb(32, 32, 32)
    $testForm.ForeColor = [System.Drawing.Color]::White
    $testForm.Font = [System.Drawing.Font]::new("Segoe UI", 10.0)
    $testForm.ShowInTaskbar = $true

    # Keep live Cursor objects strongly referenced so GC cannot destroy their
    # handles while the mouse is still over a row (that was causing the black cursor).
    $liveCursors = New-Object 'System.Collections.Generic.List[System.Windows.Forms.Cursor]'
    $lastAssignments = @()

    # ── Header ─────────────────────────────────────────────────────────────

    $title = New-Object System.Windows.Forms.Label
    $title.Text = "Current Cursor Inspector"
    $title.Font = [System.Drawing.Font]::new(
        "Segoe UI",
        17.0,
        [System.Drawing.FontStyle]::Bold
    )
    $title.AutoSize = $true
    $title.Location = [System.Drawing.Point]::new(20, 15)
    $testForm.Controls.Add($title)

    $subtitle = New-Object System.Windows.Forms.Label
    $subtitle.Text = "These are the cursor files currently assigned by Windows."
    $subtitle.ForeColor = [System.Drawing.Color]::LightGray
    $subtitle.AutoSize = $true
    $subtitle.Location = [System.Drawing.Point]::new(22, 50)
    $testForm.Controls.Add($subtitle)

    # ── Refresh button ─────────────────────────────────────────────────────

    $refreshButton = New-Object System.Windows.Forms.Button
    $refreshButton.Text = "Refresh"
    $refreshButton.Size = [System.Drawing.Size]::new(110, 35)
    $refreshButton.Location = [System.Drawing.Point]::new(580, 15)
    $refreshButton.Anchor = (
        [System.Windows.Forms.AnchorStyles]::Top -bor
        [System.Windows.Forms.AnchorStyles]::Right
    )
    $refreshButton.FlatStyle = "Flat"
    $refreshButton.BackColor = [System.Drawing.Color]::FromArgb(70, 130, 180)
    $refreshButton.ForeColor = [System.Drawing.Color]::White
    $refreshButton.FlatAppearance.BorderSize = 0
    $testForm.Controls.Add($refreshButton)

    # ── Export button ──────────────────────────────────────────────────────

    $exportButton = New-Object System.Windows.Forms.Button
    $exportButton.Text = "Export Paths"
    $exportButton.Size = [System.Drawing.Size]::new(110, 35)
    $exportButton.Location = [System.Drawing.Point]::new(700, 15)
    $exportButton.Anchor = (
        [System.Windows.Forms.AnchorStyles]::Top -bor
        [System.Windows.Forms.AnchorStyles]::Right
    )
    $exportButton.FlatStyle = "Flat"
    $exportButton.BackColor = [System.Drawing.Color]::FromArgb(60, 140, 90)
    $exportButton.ForeColor = [System.Drawing.Color]::White
    $exportButton.FlatAppearance.BorderSize = 0
    $testForm.Controls.Add($exportButton)

    # ── Scroll area ────────────────────────────────────────────────────────

    $scroll = New-Object System.Windows.Forms.Panel
    $scroll.Location = [System.Drawing.Point]::new(15, 85)
    $scroll.Size = [System.Drawing.Size]::new(805, 545)
    $scroll.Anchor = (
        [System.Windows.Forms.AnchorStyles]::Top -bor
        [System.Windows.Forms.AnchorStyles]::Bottom -bor
        [System.Windows.Forms.AnchorStyles]::Left -bor
        [System.Windows.Forms.AnchorStyles]::Right
    )
    $scroll.AutoScroll = $true
    $scroll.BackColor = [System.Drawing.Color]::FromArgb(42, 42, 42)
    $testForm.Controls.Add($scroll)

    # ── Bottom label ───────────────────────────────────────────────────────

    $bottom = New-Object System.Windows.Forms.Label
    $bottom.Text = "Hover over a row to test that cursor."
    $bottom.ForeColor = [System.Drawing.Color]::LightGreen
    $bottom.AutoSize = $true
    $bottom.Location = [System.Drawing.Point]::new(20, 645)
    $bottom.Anchor = (
        [System.Windows.Forms.AnchorStyles]::Bottom -bor
        [System.Windows.Forms.AnchorStyles]::Left
    )
    $testForm.Controls.Add($bottom)

    # ── Clear previous live cursors + images ───────────────────────────────

    function Clear-LiveResources {
        foreach ($ctrl in @($scroll.Controls)) {
            if ($ctrl -is [System.Windows.Forms.Panel]) {
                foreach ($child in @($ctrl.Controls)) {
                    if (
                        $child -is [System.Windows.Forms.PictureBox] -and
                        $null -ne $child.Image
                    ) {
                        $oldImg = $child.Image
                        $child.Image = $null
                        try { $oldImg.Dispose() } catch { }
                    }
                    # Detach cursor references before disposing live list
                    try { $child.Cursor = [System.Windows.Forms.Cursors]::Default } catch { }
                }
                try { $ctrl.Cursor = [System.Windows.Forms.Cursors]::Default } catch { }
            }
        }

        $scroll.Controls.Clear()

        foreach ($c in @($liveCursors)) {
            try { $c.Dispose() } catch { }
        }
        $liveCursors.Clear()
    }

    # ── Populate cursor list ───────────────────────────────────────────────

    function Load-CursorList {

        Clear-LiveResources

        $script:lastAssignments = @(Get-CurrentCursorAssignments)

        $y = 10

        foreach ($item in $script:lastAssignments) {

            $row = New-Object System.Windows.Forms.Panel
            $row.Location = [System.Drawing.Point]::new(10, $y)
            $row.Size = [System.Drawing.Size]::new(750, 88)
            $row.BackColor = [System.Drawing.Color]::FromArgb(58, 58, 58)
            $row.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle

            # ── Preview ────────────────────────────────────────────────────

            $preview = New-Object System.Windows.Forms.PictureBox
            $preview.Location = [System.Drawing.Point]::new(10, 10)
            $preview.Size = [System.Drawing.Size]::new(68, 68)
            $preview.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::CenterImage
            $preview.BackColor = [System.Drawing.Color]::FromArgb(40, 40, 40)

            $image = $null
            try {
                $image = Get-CursorImage -Path $item.Path
            }
            catch { }

            if ($null -ne $image) {
                $preview.Image = $image
            }

            # Create ONE Cursor per row and keep it in $liveCursors so GC
            # cannot destroy the handle while the mouse is over the control.
            $rowCursor = $null
            if (
                -not [string]::IsNullOrWhiteSpace($item.Path) -and
                (Test-Path -LiteralPath $item.Path)
            ) {
                try {
                    $rowCursor = [System.Windows.Forms.Cursor]::new($item.Path)
                    $liveCursors.Add($rowCursor)
                }
                catch {
                    $rowCursor = $null
                }
            }

            if ($null -ne $rowCursor) {
                $preview.Cursor = $rowCursor
                $row.Cursor = $rowCursor
            }

            $row.Controls.Add($preview)

            # ── Role ───────────────────────────────────────────────────────

            $roleLabel = New-Object System.Windows.Forms.Label
            $roleLabel.Text = $item.Role
            $roleLabel.Font = [System.Drawing.Font]::new(
                "Segoe UI",
                10.0,
                [System.Drawing.FontStyle]::Bold
            )
            $roleLabel.ForeColor = [System.Drawing.Color]::White
            $roleLabel.AutoSize = $true
            $roleLabel.Location = [System.Drawing.Point]::new(95, 12)
            if ($null -ne $rowCursor) { $roleLabel.Cursor = $rowCursor }
            $row.Controls.Add($roleLabel)

            # ── Filename ──────────────────────────────────────────────────

            $fileLabel = New-Object System.Windows.Forms.Label
            $fileLabel.Text = "File: " + $item.FileName
            $fileLabel.ForeColor = [System.Drawing.Color]::LightGreen
            $fileLabel.AutoSize = $true
            $fileLabel.Location = [System.Drawing.Point]::new(95, 38)
            if ($null -ne $rowCursor) { $fileLabel.Cursor = $rowCursor }
            $row.Controls.Add($fileLabel)

            # ── Full path ──────────────────────────────────────────────────

            $pathLabel = New-Object System.Windows.Forms.Label

            if ([string]::IsNullOrWhiteSpace($item.Path)) {
                $pathLabel.Text = "No cursor assigned"
                $pathLabel.ForeColor = [System.Drawing.Color]::Salmon
            }
            else {
                $pathLabel.Text = $item.Path
                $pathLabel.ForeColor = [System.Drawing.Color]::Gray
            }

            $pathLabel.AutoSize = $false
            $pathLabel.Size = [System.Drawing.Size]::new(620, 20)
            $pathLabel.Location = [System.Drawing.Point]::new(95, 61)
            $pathLabel.AutoEllipsis = $true
            if ($null -ne $rowCursor) { $pathLabel.Cursor = $rowCursor }
            $row.Controls.Add($pathLabel)

            $scroll.Controls.Add($row)

            $y += 96
        }

        $scroll.AutoScrollMinSize = [System.Drawing.Size]::new(0, ($y + 10))
    }

    # ── Export paths as txt ────────────────────────────────────────────────

    function Export-CursorPaths {
        if (-not (Test-Path -LiteralPath $ExportsDir)) {
            New-Item -ItemType Directory -Path $ExportsDir -Force | Out-Null
        }

        $stamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
        $fileName = "cursor_paths_$stamp.txt"
        $filePath = Join-Path $ExportsDir $fileName

        $lines = @()
        foreach ($item in $script:lastAssignments) {
            if (-not [string]::IsNullOrWhiteSpace($item.Path)) {
                $lines += $item.Path
            }
        }

        $utf8 = New-Object System.Text.UTF8Encoding $false
        [System.IO.File]::WriteAllLines($filePath, $lines, $utf8)

        return $filePath
    }

    # ── Refresh click ──────────────────────────────────────────────────────

    $refreshButton.Add_Click({
        try {
            Load-CursorList
            $bottom.Text = "Cursor list refreshed."
            $bottom.ForeColor = [System.Drawing.Color]::LightGreen
        }
        catch {
            Write-ErrorLog -ErrorRecord $_ -Context "CursorInspector-Refresh"
            $bottom.Text = "Error: " + $_.Exception.Message
            $bottom.ForeColor = [System.Drawing.Color]::Salmon
        }
    })

    # ── Export click ───────────────────────────────────────────────────────

    $exportButton.Add_Click({
        try {
            if ($script:lastAssignments.Count -eq 0) {
                Load-CursorList
            }
            $outPath = Export-CursorPaths
            $bottom.Text = "Exported to: $outPath"
            $bottom.ForeColor = [System.Drawing.Color]::LightGreen
        }
        catch {
            Write-ErrorLog -ErrorRecord $_ -Context "CursorInspector-Export"
            $bottom.Text = "Export error: " + $_.Exception.Message
            $bottom.ForeColor = [System.Drawing.Color]::Salmon
        }
    })

    # Dispose live cursors when the window closes
    $testForm.Add_FormClosed({
        Clear-LiveResources
    })

    # Initial load
    try {
        Load-CursorList
    }
    catch {
        Write-ErrorLog -ErrorRecord $_ -Context "CursorInspector-InitialLoad"
        $bottom.Text = "Error loading cursors: " + $_.Exception.Message
        $bottom.ForeColor = [System.Drawing.Color]::Salmon
    }

    # ── Show independent window ────────────────────────────────────────────

    [void]$testForm.ShowDialog()
}

# ── Discover Mods ──────────────────────────────────────────────────────────

$AvailableMods = Get-AvailableMods

# ── Main GUI ───────────────────────────────────────────────────────────────

$form = New-Object System.Windows.Forms.Form

$form.Text = "CursorToggle - Mod Manager"
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false
$form.MinimizeBox = $true
$form.TopMost = $false
$form.ShowInTaskbar = $true

$form.BackColor = [System.Drawing.Color]::FromArgb(32, 32, 32)
$form.Font = [System.Drawing.Font]::new("Segoe UI", 10.0)
$form.Size = [System.Drawing.Size]::new(320, 410)

# ── Status ─────────────────────────────────────────────────────────────────

$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Text = "Ready"
$lblStatus.ForeColor = [System.Drawing.Color]::LightGreen
$lblStatus.AutoSize = $false
$lblStatus.TextAlign = "MiddleCenter"
$lblStatus.Size = [System.Drawing.Size]::new(280, 28)
$lblStatus.Location = [System.Drawing.Point]::new(12, 12)
$form.Controls.Add($lblStatus)

# ── Scroll panel ───────────────────────────────────────────────────────────

$scrollPanel = New-Object System.Windows.Forms.Panel
$scrollPanel.Location = [System.Drawing.Point]::new(8, 48)
$scrollPanel.Size = [System.Drawing.Size]::new(296, 250)

$scrollPanel.AutoScroll = $true

$scrollPanel.BackColor = [System.Drawing.Color]::FromArgb(
    42,
    42,
    42
)

$form.Controls.Add($scrollPanel)

$yOffset = 12
$buttonHeight = 40
$buttonGap = 8

# ── Mod buttons ────────────────────────────────────────────────────────────

$modButtons = @()

foreach ($mod in $AvailableMods) {

    $btn = New-Object System.Windows.Forms.Button

    $btn.Text = $mod.Name

    $btn.Size = [System.Drawing.Size]::new(260, $buttonHeight)
    $btn.Location = [System.Drawing.Point]::new(12, $yOffset)

    $btn.FlatStyle = "Flat"
    $btn.BackColor = [System.Drawing.Color]::FromArgb(70, 130, 180)

    $btn.ForeColor = [System.Drawing.Color]::White
    $btn.FlatAppearance.BorderSize = 0
    $btn.Tag = $mod

    $scrollPanel.Controls.Add($btn)

    $modButtons += $btn

    $btn.Add_Click({

        try {

            $modInfo = $this.Tag

            Set-Busy `
                $true `
                "Applying $($modInfo.Name)..."

            Apply-CursorPack `
                -ModName $modInfo.Name `
                -PackDir $modInfo.Path

            Set-Busy `
                $false `
                "$($modInfo.Name) applied"
        }
        catch {
            Write-ErrorLog -ErrorRecord $_ -Context "ApplyMod-$($this.Tag.Name)"
            Set-Busy $false "Error: $($_.Exception.Message)"
            $lblStatus.ForeColor = [System.Drawing.Color]::Salmon
        }
    })

    $yOffset += $buttonHeight + $buttonGap
}

# ── Default button ─────────────────────────────────────────────────────────

$btnDefault = New-Object System.Windows.Forms.Button

$btnDefault.Text = "System Default"

$btnDefault.Size = [System.Drawing.Size]::new(260, $buttonHeight)
$btnDefault.Location = [System.Drawing.Point]::new(12, $yOffset)

$btnDefault.FlatStyle = "Flat"

$btnDefault.BackColor = [System.Drawing.Color]::FromArgb(
    90,
    90,
    90
)

$btnDefault.ForeColor = [System.Drawing.Color]::White
$btnDefault.FlatAppearance.BorderSize = 0

$scrollPanel.Controls.Add($btnDefault)

# ── Cursor Test Button ─────────────────────────────────────────────────────

$btnCursorTest = New-Object System.Windows.Forms.Button

$btnCursorTest.Text = "Cursor Test / Inspector"

$btnCursorTest.Size = [System.Drawing.Size]::new(260, 40)
$btnCursorTest.Location = [System.Drawing.Point]::new(28, 310)

$btnCursorTest.FlatStyle = "Flat"

$btnCursorTest.BackColor = [System.Drawing.Color]::FromArgb(
    110,
    80,
    160
)

$btnCursorTest.ForeColor = [System.Drawing.Color]::White
$btnCursorTest.FlatAppearance.BorderSize = 0

$form.Controls.Add($btnCursorTest)

# ── Busy handling ──────────────────────────────────────────────────────────

$allModButtons = $modButtons + @(
    $btnDefault
)

function Set-Busy {

    param(
        [bool]$Busy,
        [string]$Message = "Ready"
    )

    foreach ($btn in $allModButtons) {
        $btn.Enabled = -not $Busy
    }

    $lblStatus.Text = $Message

    if ($Busy) {

        $lblStatus.ForeColor = (
            [System.Drawing.Color]::Orange
        )
    }
    else {

        $lblStatus.ForeColor = (
            [System.Drawing.Color]::LightGreen
        )
    }

    [System.Windows.Forms.Application]::DoEvents()
}

# ── Default button ─────────────────────────────────────────────────────────

$btnDefault.Add_Click({

    try {

        Set-Busy `
            $true `
            "Restoring System Default..."

        Apply-SystemDefault

        Set-Busy `
            $false `
            "System Default restored"
    }
    catch {
        Write-ErrorLog -ErrorRecord $_ -Context "ApplySystemDefault"
        Set-Busy $false "Error: $($_.Exception.Message)"
        $lblStatus.ForeColor = [System.Drawing.Color]::Salmon
    }
})

# ── Cursor Test button ─────────────────────────────────────────────────────

$btnCursorTest.Add_Click({

    try {
        Show-CursorTestWindow
    }
    catch {
        Write-ErrorLog -ErrorRecord $_ -Context "CursorInspector-Open"

        [System.Windows.Forms.MessageBox]::Show(
            (
                "Could not open the Cursor Test Window.`n`n" +
                "Error:`n" +
                $_.Exception.ToString() +
                "`n`nA log was written to the 'errors' folder."
            ),
            "CursorToggle - Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
})

# ── Start main window ──────────────────────────────────────────────────────

[void]$form.ShowDialog()
