HOW TO CREATE A NEW CURSOR MOD
==============================

1. RENAME THIS FOLDER
   - Right-click on "TEMPLATE - Copy Me"
   - Rename it to something descriptive (e.g., "My Cursors" or "Blue Theme")

2. EDIT template.crs
   - Open template.crs with Notepad
   - Change the filename paths to match your cursor files
   - Remove lines for cursor types you don't want to customize
   - Save the file
   - Optional: Rename template.crs to something like "my-cursors.crs"

3. ADD YOUR CURSOR FILES
   - Place your .cur and .ani files in this folder
   - Make sure the filenames exactly match what's in your .crs file
   - Filenames are case-insensitive but spaces/punctuation must match

4. RESTART THE APP
   - Close CursorToggle
   - Open LAUNCH.vbs again
   - Your new cursor pack should appear as a button!

EXAMPLE
=======

If you have these cursor files:
  - blue-arrow.ani
  - blue-busy.ani
  - blue-text.cur
  - blue-link.ani

Your .crs file should have:
  [Arrow]
  Path = blue-arrow.ani
  
  [Wait]
  Path = blue-busy.ani
  
  [IBeam]
  Path = blue-text.cur
  
  [Hand]
  Path = blue-link.ani

NEED MORE HELP?
===============
Read MODS_README.md in the main folder for detailed instructions!


Template location: This folder is intentionally outside the mods folder. Copy it into mods and rename it to create a new cursor pack.
