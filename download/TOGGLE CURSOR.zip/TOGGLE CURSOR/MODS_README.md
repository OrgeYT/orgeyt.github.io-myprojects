# CursorToggle - Modular Cursor Pack System

## Overview

CursorToggle now supports **modular cursor packs**! Simply add cursor packs to the `mods` folder, and the application will automatically detect and create buttons for each one.

## Folder Structure

```
TOGGLE CURSOR/
├── main.ps1                (Main application script)
├── LAUNCH.vbs              (Launcher)
├── MODS_README.md          (This file)
└── mods/                   (Cursor packs go here)
    ├── Catto Boi/          (Default mod)
    │   ├── catto-boi.crs
    │   ├── Catto Boi - normal select.ani
    │   ├── Catto Boi - busy.ani
    │   └── (other cursor files...)
    ├── Chroma/              (Included Chroma cursor pack)
    └── Your Mod Name/      (Add your cursor packs here)
        ├── your-mod.crs
        ├── your-mod - normal select.ani
        └── (other cursor files...)
```

## How to Add a Cursor Pack

### Step 1: Prepare Your Cursor Files

A cursor pack consists of:
- **Cursor files**: `.cur` (static) and `.ani` (animated) files
- **Configuration file**: A `.crs` file that maps cursor roles to file paths

### Step 2: Create the .crs File

The `.crs` file is a text-based configuration file that defines which cursor file to use for each role.

**Example: `my-cursors.crs`**
```ini
[Arrow]
Path = My Cursors - arrow.cur

[Wait]
Path = My Cursors - busy.ani

[Hand]
Path = My Cursors - link select.ani

[IBeam]
Path = My Cursors - text select.cur

[No]
Path = My Cursors - unavailable.cur

[SizeNS]
Path = My Cursors - vertical resize.cur

[SizeWE]
Path = My Cursors - horizontal resize.cur

[SizeNWSE]
Path = My Cursors - diagonal resize 1.cur

[SizeNESW]
Path = My Cursors - diagonal resize 2.cur

[SizeAll]
Path = My Cursors - move.cur

[UpArrow]
Path = My Cursors - up arrow.cur

[Help]
Path = My Cursors - help select.ani

[AppStarting]
Path = My Cursors - working.ani

[NWPen]
Path = My Cursors - pen.cur

[Person]
Path = My Cursors - person.cur

[Pin]
Path = My Cursors - pin.cur
```

### Step 3: Organize Your Files

1. Copy the `Template/` folder and rename the copy (e.g., `mods/My Cursors/`)
2. Place all cursor files (`.cur` and `.ani`) in the copied folder
3. Place your `.crs` configuration file in that folder
4. Make sure the `Path` values in your `.crs` match the actual filenames

### Step 4: Restart the Application

The mod list is scrollable, so you can add as many cursor packs as you want without making the window taller.

The application auto-detects cursor packs on startup. Simply close and reopen `LAUNCH.vbs` to see your new mod appear as a button!

## Cursor Role Reference

Here are all the cursor roles that Windows recognizes:

| Role | Purpose |
|------|---------|
| **Arrow** | Normal selection arrow |
| **Wait** | Waiting/busy indicator |
| **IBeam** | Text selection |
| **Hand** | Link/clickable element |
| **SizeNS** | Vertical resize |
| **SizeWE** | Horizontal resize |
| **SizeNWSE** | Diagonal resize (NW-SE) |
| **SizeNESW** | Diagonal resize (NE-SW) |
| **SizeAll** | Move/pan in all directions |
| **UpArrow** | Up arrow |
| **No** | Not available/unavailable |
| **Help** | Help select |
| **AppStarting** | Application loading |
| **NWPen** | Pen tool |
| **Person** | Person/user indicator |
| **Pin** | Pin |
| **Crosshair** | Crosshair (optional) |

**Note**: You don't need to define all roles. The script will only apply the ones you specify in your `.crs` file.

## Example Mod Structure

```
mods/
└── My Custom Cursors/
    ├── my-cursors.crs
    ├── My Custom Cursors - normal select.ani
    ├── My Custom Cursors - busy.ani
    ├── My Custom Cursors - link select.ani
    ├── My Custom Cursors - text select.cur
    ├── My Custom Cursors - unavailable.cur
    ├── My Custom Cursors - vertical resize.cur
    ├── My Custom Cursors - horizontal resize.cur
    ├── My Custom Cursors - diagonal resize 1.cur
    ├── My Custom Cursors - diagonal resize 2.cur
    └── My Custom Cursors - move.cur
```

## Troubleshooting

### "No .crs file found in: mods/My Mod"
- Make sure you have a `.crs` file in your mod folder
- Check that the filename ends with `.crs`

### "Missing cursor files"
- A cursor file referenced in your `.crs` is missing
- Check that the `Path` value in your `.crs` exactly matches the filename
- Windows is case-insensitive, but spaces and special characters must match exactly

### Button doesn't appear for my mod
- Make sure your folder is directly in `mods/` (not in a subfolder)
- Make sure it contains a `.crs` file
- Restart the application
- Check that there are no errors in your `.crs` file format

### Cursor doesn't apply when I click the button
- Check for error messages in the status label at the top of the window
- Verify all cursor files exist and the filenames match your `.crs` file
- Make sure your `.crs` file is valid (proper section format with `[Role]` and `Path = filename`)

## Creating Cursor Files

If you want to create custom cursors, you can use tools like:
- **CursorFX** - Commercial cursor creation tool
- **RealWorld Cursor Editor** - Free cursor editor
- **Creatorcursor.com** - Online cursor creator
- **Cursor Maker** - Simple Windows cursor creation

Cursor files should be:
- **Static cursors**: `.cur` format
- **Animated cursors**: `.ani` format
- Typically 32x32 pixels or smaller
- Compressed where possible for efficiency

## Need Help?

For issues or questions:
1. Check the Troubleshooting section above
2. Verify your `.crs` file format matches the example
3. Ensure all filenames in your `.crs` match actual files in your mod folder
4. Make sure the mod folder is directly in the `mods/` directory

---

**Created by Grok** | *Updated by Claude for modular support*
